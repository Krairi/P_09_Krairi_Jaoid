import logging
from shared_code.pred import recommandation
import azure.functions as func


def main(req: func.HttpRequest, context: func.Context) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    user_id = req.params.get('userId')

    if not user_id:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            user_id = req_body.get('userId')
    
    recommendation = req.params.get('recommendations')

    if not recommendation:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            recommendation = req_body.get('recommendations')

    if user_id:
        model = str(context.function_directory) +"./pickle_surprise_model_KNNWithMeans.pkl" 
        articles_df = str(context.function_directory) +"./articles_metadata.csv"
        recom = recommandation(model, articles_df)
        recommendations = recom.get_recommendations(user_id)
        return func.HttpResponse(f"{recommendations}")
    else:
        return func.HttpResponse(
             "Cette fonction déclenchée par HTTP a été exécutée avec succès. Passez user_id dans la chaîne de requête ou dans le corps de requête pour une réponse personnalisée.",
             status_code=200
        )

