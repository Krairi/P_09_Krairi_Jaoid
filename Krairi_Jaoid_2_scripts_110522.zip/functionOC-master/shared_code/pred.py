import logging
import pickle
import pandas as pd
import random
import os
import surprise

def predict_best_category_for_user(user_id, mod, article):
        
    predictions = {}
        
    # Catégories 1 à 460
    for i in range(1, 460):
        _, cat_id, _, est, err = mod.predict(user_id, i)
        
        # Gardez la prédiction seulement si nous pouvons la garder.
        if (err != True):
            predictions[cat_id] = est
    
    best_cats_to_recommend = dict(sorted(predictions.items(), key=lambda x: x[1], reverse=True)[:5])
    
    recommended_articles = []
    for key, _ in best_cats_to_recommend.items():
        recommended_articles.append(int(article[article['category_id'] == key]['article_id'].sample(1).values))
    
    # Retourner articles-aléatoires-pour-la-meilleure-catégorie, la-meilleure-catégorie-de-recommander
    return recommended_articles

class recommandation:

    def __init__(self, model, articles_df):

        logging.info(model)        
        self.model = model
        self.articles_df = articles_df

    def get_recommendations(self, user_id):

        logging.info(self.model)
        with open(self.model, 'rb') as file:
            pickle_model = pickle.load(file)
        article_df = pd.read_csv(self.articles_df)
        
        score_df = predict_best_category_for_user(user_id, pickle_model, article_df)
        
        return score_df
        
    

